How to use it:

1. Start MEPX application
2. Press "Load Project" button and load one of the projects in this archive. Be carefull here: XML files are project files. Do not load them with "Load training data" button.
3. Press Start button.
4. Read the results from the "Results" panel.
